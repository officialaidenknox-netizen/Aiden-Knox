import { createFileRoute } from "@tanstack/react-router";
import { parseMediaUrl } from "@/lib/media-host";

const MAX_BYTES = 80 * 1024 * 1024;

function safeName(raw: string | null, type: string): string {
  const cleaned = (raw || "aiden-knox")
    .replace(/[^a-zA-Z0-9._-]/g, "")
    .replace(/^\.+/, "")
    .slice(0, 80);
  const base = (cleaned || "aiden-knox").replace(/\.[a-z0-9]+$/i, "");
  let ext = "bin";
  if (type.includes("mp4")) ext = "mp4";
  else if (type.includes("mpeg") || type.includes("audio")) ext = "mp3";
  else if (type.includes("webm")) ext = "webm";
  else if (type.includes("webp")) ext = "webp";
  else if (type.includes("png")) ext = "png";
  else if (type.includes("jpeg") || type.includes("jpg")) ext = "jpg";
  else if (type.includes("gif")) ext = "gif";
  return `${base}.${ext}`;
}

function allowedType(type: string): boolean {
  return (
    type.startsWith("video/") ||
    type.startsWith("audio/") ||
    type.startsWith("image/") ||
    type.startsWith("application/octet-stream")
  );
}

export const Route = createFileRoute("/api/media")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const incoming = new URL(request.url);
        const src = parseMediaUrl(incoming.searchParams.get("src") || "");
        if (!src) {
          return Response.json({ error: "That file link is not allowed." }, { status: 400 });
        }
        const inline = incoming.searchParams.get("disp") === "inline";
        let upstream: Response;
        try {
          upstream = await fetch(src, {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
              Referer: "https://www.tiktok.com/",
              Accept: "*/*",
            },
            redirect: "follow",
            signal: AbortSignal.timeout(25000),
          });
        } catch {
          return Response.json({ error: "The file host did not respond." }, { status: 502 });
        }
        if (!upstream.ok || !upstream.body) {
          return Response.json({ error: "The file could not be fetched." }, { status: 502 });
        }
        const finalHost = (() => {
          try {
            return new URL(upstream.url).hostname;
          } catch {
            return "";
          }
        })();
        if (!parseMediaUrl(`https://${finalHost}/`)) {
          return Response.json({ error: "Redirected host is not allowed." }, { status: 400 });
        }
        const type = (upstream.headers.get("content-type") || "application/octet-stream")
          .split(";")[0]
          .trim()
          .toLowerCase();
        if (!allowedType(type)) {
          return Response.json({ error: "Unexpected file type." }, { status: 415 });
        }
        const length = Number(upstream.headers.get("content-length") || 0);
        if (length > MAX_BYTES) {
          return Response.json({ error: "That file is too large to save here." }, { status: 413 });
        }
        const filename = safeName(incoming.searchParams.get("name"), type);
        const headers = new Headers();
        headers.set("Content-Type", type);
        headers.set(
          "Content-Disposition",
          `${inline ? "inline" : "attachment"}; filename="${filename}"`,
        );
        headers.set("Cache-Control", "private, max-age=120");
        headers.set("X-Content-Type-Options", "nosniff");
        if (length > 0) headers.set("Content-Length", String(length));
        return new Response(upstream.body, { status: 200, headers });
      },
    },
  },
});
