import { createFileRoute } from "@tanstack/react-router";
import { motionJpeg } from "@/lib/live-photo.server";
import { parseMediaUrl } from "@/lib/media-host";

const STILL_MAX = 12 * 1024 * 1024;
const MOTION_MAX = 20 * 1024 * 1024;

async function pull(url: URL, max: number): Promise<Uint8Array> {
  const upstream = await fetch(url, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      Referer: "https://www.tiktok.com/",
      Accept: "*/*",
    },
    redirect: "follow",
    signal: AbortSignal.timeout(25000),
  });
  if (!upstream.ok) throw new Error("A Live Photo file could not be fetched.");
  let finalHost = "";
  try {
    finalHost = new URL(upstream.url).hostname;
  } catch {
    finalHost = "";
  }
  if (!parseMediaUrl(`https://${finalHost}/`)) throw new Error("Redirected host is not allowed.");
  const length = Number(upstream.headers.get("content-length") || 0);
  if (length > max) throw new Error("That Live Photo is too large to build.");
  const body = new Uint8Array(await upstream.arrayBuffer());
  if (body.byteLength > max) throw new Error("That Live Photo is too large to build.");
  return body;
}

export const Route = createFileRoute("/api/live")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const incoming = new URL(request.url);
        const stillUrl = parseMediaUrl(incoming.searchParams.get("still") || "");
        const motionUrl = parseMediaUrl(incoming.searchParams.get("motion") || "");
        if (!stillUrl || !motionUrl) {
          return Response.json({ error: "That Live Photo link is not allowed." }, { status: 400 });
        }
        try {
          const [still, motion] = await Promise.all([
            pull(stillUrl, STILL_MAX),
            pull(motionUrl, MOTION_MAX),
          ]);
          const photo = motionJpeg(still, motion);
          const name = (incoming.searchParams.get("name") || "aiden-knox-live-photo.jpg")
            .replace(/[^a-zA-Z0-9._-]/g, "")
            .replace(/\.mp4$/i, "")
            .slice(0, 80);
          const filename = name.replace(/\.[a-z0-9]+$/i, "") || "aiden-knox-live-photo";
          const bytes = new ArrayBuffer(photo.byteLength);
          new Uint8Array(bytes).set(photo);
          return new Response(bytes, {
            status: 200,
            headers: {
              "Content-Type": "image/jpeg",
              "Content-Disposition": `attachment; filename="${filename}.jpg"`,
              "Cache-Control": "private, max-age=60",
              "X-Content-Type-Options": "nosniff",
            },
          });
        } catch (err) {
          const message = err instanceof Error ? err.message : "Couldn't build that Live Photo.";
          const status = /not a JPEG|not a video/i.test(message) ? 415 : 502;
          return Response.json({ error: message }, { status });
        }
      },
    },
  },
});
