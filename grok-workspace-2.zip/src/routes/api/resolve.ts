import { createFileRoute } from "@tanstack/react-router";
import { parseMediaUrl } from "@/lib/media-host";
import { parseTikTokTarget, type PhotoSlide, type ResolvedMedia } from "@/lib/tiktok";

const LOOKUP = "https://www.tikwm.com/api/";
const PROFILE = "https://www.tikwm.com/api/user/info/";

function asRecord(v: unknown): Record<string, unknown> | null {
  return v !== null && typeof v === "object" ? (v as Record<string, unknown>) : null;
}

function str(v: unknown): string {
  return typeof v === "string" ? v.trim() : "";
}

function num(v: unknown): number | null {
  const n = typeof v === "number" ? v : typeof v === "string" ? Number(v) : NaN;
  return Number.isFinite(n) ? n : null;
}

function httpsMedia(v: unknown): string | null {
  const value = str(v);
  if (!value) return null;
  return parseMediaUrl(value)?.toString() ?? null;
}

function looksJpeg(url: string): boolean {
  return !/\.webp(\?|$)/i.test(url);
}

function jpegFirst(urls: (string | null | undefined)[]): string | null {
  const clean = urls.filter((url): url is string => Boolean(url));
  return clean.find(looksJpeg) ?? null;
}

function slideFrom(item: unknown): PhotoSlide | null {
  if (typeof item === "string") {
    const url = httpsMedia(item);
    return url ? { url, motion: null } : null;
  }
  const rec = asRecord(item);
  if (!rec) return null;
  const url = httpsMedia(rec.url ?? rec.image ?? rec.src ?? rec.display_image);
  if (!url) return null;
  const motion = httpsMedia(rec.video ?? rec.play ?? rec.motion ?? rec.video_url);
  return { url, motion };
}

function photosFrom(data: Record<string, unknown>): PhotoSlide[] {
  if (!Array.isArray(data.images)) return [];
  const out: PhotoSlide[] = [];
  for (const item of data.images) {
    const slide = slideFrom(item);
    if (slide) out.push(slide);
  }
  return out;
}

function friendly(msg: string): string {
  const t = msg.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  if (/limit|too many|frequent|request\/second/i.test(t)) {
    return "Too many lookups at once. Wait a moment and try again.";
  }
  if (/private/i.test(t)) return "That post is private or unavailable.";
  if (/url|pars|not found|invalid|empty/i.test(t)) {
    return "That link didn't resolve. Use a public TikTok video or photo link.";
  }
  return t.slice(0, 180) || "Couldn't download that post.";
}

function mapPayload(
  data: Record<string, unknown>,
  sourceUrl: string,
  avatarUrl: string | null,
  avatarIsHd: boolean,
): ResolvedMedia {
  const author = asRecord(data.author);
  const music = asRecord(data.music_info);
  const photos = photosFrom(data);
  const videoUrl = httpsMedia(data.play);
  const hdCandidate = httpsMedia(data.hdplay);
  const hdUrl = hdCandidate && hdCandidate !== videoUrl ? hdCandidate : null;
  const motion = hdUrl ?? videoUrl;
  const audioUrl = httpsMedia(data.music) ?? httpsMedia(music?.play);
  const id = str(data.id) || "post";
  const title = str(data.title) || "TikTok post";
  const durationSec = num(data.duration);
  const cover = httpsMedia(data.cover) ?? httpsMedia(data.origin_cover);
  const liveStill = jpegFirst([cover, httpsMedia(data.origin_cover), photos[0]?.url]);
  const slideMotions = photos.filter((photo) => photo.motion).length;
  const isLive = Boolean(
    liveStill &&
      motion &&
      ((durationSec != null && durationSec > 0 && durationSec <= 6 && photos.length <= 1) ||
        (photos.length === 1 && photos[0]?.motion)),
  );

  if (!videoUrl && !hdUrl && photos.length === 0 && !audioUrl && !avatarUrl) {
    throw new Error("No downloadable file was published for that post.");
  }

  let kind: ResolvedMedia["kind"] = "video";
  if (isLive) kind = "live";
  else if (!videoUrl && !hdUrl && photos.length > 0) kind = "photo";

  return {
    id,
    sourceUrl,
    kind,
    title,
    authorName: str(author?.nickname) || "TikTok",
    authorHandle: str(author?.unique_id),
    cover,
    durationSec,
    plays: num(data.play_count),
    likes: num(data.digg_count),
    videoUrl,
    videoBytes: num(data.size),
    hdUrl,
    hdBytes: num(data.hd_size),
    audioUrl,
    audioTitle: str(music?.title) || null,
    photos,
    avatarUrl: avatarUrl ?? httpsMedia(author?.avatar),
    avatarIsHd,
    liveStill: isLive ? liveStill : slideMotions > 0 ? jpegFirst(photos.map((photo) => photo.url)) : null,
    liveMotion: isLive ? (photos[0]?.motion ?? motion) : (photos.find((photo) => photo.motion)?.motion ?? null),
  };
}

async function profileAvatar(handle: string): Promise<{ url: string; hd: boolean } | null> {
  const endpoint = new URL(PROFILE);
  endpoint.searchParams.set("unique_id", handle);
  const res = await fetch(endpoint, {
    headers: {
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0 (compatible; AidenKnox/1.0)",
    },
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) return null;
  let json: unknown;
  try {
    json = await res.json();
  } catch {
    return null;
  }
  const rec = asRecord(json);
  const user = asRecord(asRecord(rec?.data)?.user);
  if (num(rec?.code) !== 0 || !user) return null;
  const larger = httpsMedia(user.avatarLarger);
  const medium = httpsMedia(user.avatarMedium);
  const thumb = httpsMedia(user.avatarThumb);
  const url = larger ?? medium ?? thumb;
  if (!url) return null;
  return { url, hd: Boolean(larger || medium) };
}

function profileMedia(
  handle: string,
  user: Record<string, unknown>,
  avatarUrl: string,
  avatarIsHd: boolean,
): ResolvedMedia {
  return {
    id: str(user.id) || handle,
    sourceUrl: `https://www.tiktok.com/@${handle}`,
    kind: "profile",
    title: str(user.signature) || `${str(user.nickname) || handle} profile picture`,
    authorName: str(user.nickname) || handle,
    authorHandle: str(user.uniqueId) || handle,
    cover: avatarUrl,
    durationSec: null,
    plays: null,
    likes: null,
    videoUrl: null,
    videoBytes: null,
    hdUrl: null,
    hdBytes: null,
    audioUrl: null,
    audioTitle: null,
    photos: [],
    avatarUrl,
    avatarIsHd,
    liveStill: null,
    liveMotion: null,
  };
}

async function lookup(url: string): Promise<ResolvedMedia> {
  let last = "Couldn't reach the downloader. Try again in a moment.";
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const res = await fetch(LOOKUP, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        Accept: "application/json",
        "User-Agent": "Mozilla/5.0 (compatible; AidenKnox/1.0)",
      },
      body: new URLSearchParams({ url, hd: "1" }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      last = `Lookup failed (${res.status}). Try again.`;
      await new Promise((r) => setTimeout(r, 1200));
      continue;
    }
    let json: unknown;
    try {
      json = await res.json();
    } catch {
      throw new Error("The lookup service returned an unexpected response.");
    }
    const rec = asRecord(json);
    const code = num(rec?.code);
    const data = asRecord(rec?.data);
    if (code === 0 && data) {
      const author = asRecord(data.author);
      const handle = str(author?.unique_id);
      let avatarUrl = httpsMedia(author?.avatar);
      let avatarIsHd = false;
      if (handle) {
        await new Promise((r) => setTimeout(r, 1100));
        try {
          const hd = await profileAvatar(handle);
          if (hd) {
            avatarUrl = hd.url;
            avatarIsHd = hd.hd;
          }
        } catch {
          /* the post still downloads without the HD portrait */
        }
      }
      return mapPayload(data, url, avatarUrl, avatarIsHd);
    }
    const message = friendly(str(rec?.msg));
    if (/wait a moment/i.test(message) && attempt === 0) {
      await new Promise((r) => setTimeout(r, 1300));
      last = message;
      continue;
    }
    throw new Error(message);
  }
  throw new Error(last);
}

async function lookupProfile(handle: string): Promise<ResolvedMedia> {
  const endpoint = new URL(PROFILE);
  endpoint.searchParams.set("unique_id", handle);
  const res = await fetch(endpoint, {
    headers: {
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0 (compatible; AidenKnox/1.0)",
    },
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error("Couldn't reach that profile. Try again.");
  let json: unknown;
  try {
    json = await res.json();
  } catch {
    throw new Error("The lookup service returned an unexpected response.");
  }
  const rec = asRecord(json);
  const user = asRecord(asRecord(rec?.data)?.user);
  if (num(rec?.code) !== 0 || !user) throw new Error(friendly(str(rec?.msg)));
  const larger = httpsMedia(user.avatarLarger);
  const medium = httpsMedia(user.avatarMedium);
  const avatarUrl = larger ?? medium ?? httpsMedia(user.avatarThumb);
  if (!avatarUrl) throw new Error("No profile picture was published for that account.");
  return profileMedia(handle, user, avatarUrl, Boolean(larger || medium));
}

export const Route = createFileRoute("/api/resolve")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "Send a TikTok link." }, { status: 400 });
        }
        const raw = asRecord(body);
        const target = parseTikTokTarget(str(raw?.url));
        if (!target) {
          return Response.json(
            { error: "Paste a TikTok video, live photo, or profile link." },
            { status: 400 },
          );
        }
        try {
          const media = target.type === "profile" ? await lookupProfile(target.handle) : await lookup(target.url);
          return Response.json({ media });
        } catch (err) {
          const message = err instanceof Error ? err.message : "Couldn't download that post.";
          return Response.json({ error: message }, { status: 422 });
        }
      },
    },
  },
});
