import { createFileRoute } from "@tanstack/react-router";
import { Downloader } from "@/components/downloader";
import { GlowField } from "@/components/glow-field";

export const Route = createFileRoute("/")({
  component: Home,
});

const STEPS = [
  {
    n: "1",
    title: "Copy the share link",
    body: "In TikTok, open Share and choose Copy link. Videos and photo posts both work, including vm.tiktok.com shorts.",
  },
  {
    n: "2",
    title: "Paste it into Aiden Knox",
    body: "Drop the link in the box and tap Get download. Private or deleted posts can’t be fetched.",
  },
  {
    n: "3",
    title: "Save the clean file",
    body: "Pick MP4, MP4 HD, a Live Photo, MP3, or an HD profile picture. Watermarked copies are never offered.",
  },
];

function Home() {
  return (
    <div className="relative min-h-screen overflow-x-clip">
      <GlowField />
      <div className="relative z-10">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/90">
        <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-3">
          <a href="#top" className="flex min-w-0 items-center gap-2.5">
            <img src="/aiden-pfp.jpg" alt="" className="pfp-mini" />
            <h1 className="truncate font-display text-lg font-semibold tracking-tight text-ink">
              Aiden Knox
            </h1>
          </a>
          <a href="#how" className="shrink-0 text-sm font-semibold text-ink">
            How it works
          </a>
        </div>
      </header>

      <main id="top" className="mx-auto w-full max-w-md px-3 py-4">
        <section className="neon-card min-w-0 rounded-2xl border border-line bg-surface-2 p-3">
          <Downloader />
        </section>
      </main>

      <section id="how" className="scroll-mt-16 border-t border-line">
        <div className="mx-auto max-w-md px-4 py-8">
          <h2 className="font-display text-2xl font-semibold tracking-tight text-ink">
            How to save a TikTok video with no watermark
          </h2>
          <ol className="mt-5 flex flex-col gap-3">
            {STEPS.map((step) => (
              <li key={step.n} className="rounded-2xl border border-line bg-surface p-4">
                <span className="flex size-8 items-center justify-center rounded-full bg-bar text-sm font-semibold text-bar-fg">
                  {step.n}
                </span>
                <h3 className="mt-3 text-base font-semibold text-ink">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{step.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto max-w-md px-4 py-8">
          <h2 className="font-display text-2xl font-semibold tracking-tight text-ink">Questions</h2>
          <div className="mt-4 flex flex-col gap-3">
            <details className="rounded-2xl border border-line bg-surface px-4 py-3">
              <summary className="cursor-pointer text-base font-semibold text-ink">
                Is the TikTok watermark removed?
              </summary>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                Yes. Download MP4 and Download MP4 HD are the files without the platform watermark. Aiden Knox does not offer the watermarked version.
              </p>
            </details>
            <details className="rounded-2xl border border-line bg-surface px-4 py-3">
              <summary className="cursor-pointer text-base font-semibold text-ink">
                When is HD available?
              </summary>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                HD appears when TikTok published a higher-quality source. If it didn’t, you still get the clean MP4.
              </p>
            </details>
            <details className="rounded-2xl border border-line bg-surface px-4 py-3">
              <summary className="cursor-pointer text-base font-semibold text-ink">
                Is a Live Photo a video file?
              </summary>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                No. Download Live Photo saves one JPEG photo with the motion inside it, without the watermark. It does not save an MP4.
              </p>
            </details>
            <details className="rounded-2xl border border-line bg-surface px-4 py-3">
              <summary className="cursor-pointer text-base font-semibold text-ink">
                How do I get a profile picture in HD?
              </summary>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                Paste a profile link or @username, or download any of their posts. Download profile picture HD uses the largest portrait TikTok published.
              </p>
            </details>
            <details className="rounded-2xl border border-line bg-surface px-4 py-3">
              <summary className="cursor-pointer text-base font-semibold text-ink">
                What am I allowed to download?
              </summary>
              <p className="mt-2 text-sm leading-relaxed text-muted">
                Only public posts you have the right to save. Aiden Knox is for personal copies — credit creators if you share their work again.
              </p>
            </details>
          </div>
        </div>
      </section>

      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-md flex-col gap-1 px-4 py-6 text-sm text-faint">
          <p className="font-display text-base text-ink">Aiden Knox</p>
          <p>Public TikTok posts only. Not affiliated with TikTok.</p>
        </div>
      </footer>
      </div>
    </div>
  );
}
