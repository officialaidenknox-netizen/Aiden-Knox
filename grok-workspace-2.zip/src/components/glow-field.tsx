import { useEffect, useRef } from "react";

type Spark = {
  x: number;
  y: number;
  r: number;
  v: number;
  a: number;
  tw: number;
};

export function GlowField() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduce =
      window.matchMedia("(prefers-reduced-motion: reduce), (pointer: coarse), (max-width: 900px)").matches;
    if (reduce) return;
    let frame = 0;
    let alive = true;
    const sparks: Spark[] = [];

    function resize() {
      const narrow = window.innerWidth < 720;
      const dpr = narrow ? 1 : Math.min(window.devicePixelRatio || 1, 1.5);
      canvas!.width = Math.floor(window.innerWidth * dpr);
      canvas!.height = Math.floor(window.innerHeight * dpr);
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function seed() {
      sparks.length = 0;
      const count = window.innerWidth < 720 ? 14 : 28;
      for (let i = 0; i < count; i += 1) {
        sparks.push({
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          r: Math.random() < 0.15 ? 1.6 : 0.7 + Math.random() * 0.7,
          v: 0.12 + Math.random() * 0.28,
          a: 0.35 + Math.random() * 0.5,
          tw: Math.random() * Math.PI * 2,
        });
      }
    }

    function draw(time: number) {
      if (!alive) return;
      if (document.hidden) {
        frame = window.requestAnimationFrame(draw);
        return;
      }
      const w = window.innerWidth;
      const h = window.innerHeight;
      ctx!.clearRect(0, 0, w, h);
      for (const spark of sparks) {
        if (!reduce) {
          spark.y -= spark.v;
          spark.tw += 0.015;
          if (spark.y < -8) {
            spark.y = h + 8;
            spark.x = Math.random() * w;
          }
        }
        const alpha = spark.a * (0.7 + 0.3 * Math.sin(spark.tw + time / 900));
        ctx!.fillStyle = `rgba(255,255,255,${alpha})`;
        ctx!.beginPath();
        ctx!.arc(spark.x, spark.y, spark.r, 0, Math.PI * 2);
        ctx!.fill();
      }
      if (!reduce) frame = window.requestAnimationFrame(draw);
    }

    resize();
    seed();
    frame = window.requestAnimationFrame(draw);
    const onResize = () => {
      resize();
      seed();
    };
    window.addEventListener("resize", onResize);
    return () => {
      alive = false;
      window.cancelAnimationFrame(frame);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0 h-full w-full max-w-full"
    />
  );
}
