import { useEffect, useId, useRef, useState } from "react";
import {
  ClipboardPaste,
  Download,
  Eye,
  Heart,
  ImageIcon,
  Lightbulb,
  Loader2,
  Music,
  Play,
  RotateCcw,
} from "lucide-react";
import {
  SAMPLE_URL,
  fileSlug,
  formatCount,
  formatDuration,
  mediaHref,
  parseTikTokTarget,
  type ResolvedMedia,
} from "@/lib/tiktok";

type HistoryItem = {
  url: string;
  title: string;
  handle: string;
  at: number;
};

const HISTORY_KEY = "aiden-knox-history";

function readHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is HistoryItem =>
        !!item &&
        typeof item === "object" &&
        typeof (item as HistoryItem).url === "string" &&
        typeof (item as HistoryItem).title === "string",
    );
  } catch {
    return [];
  }
}

function writeHistory(items: HistoryItem[]) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 6)));
  } catch {
    /* ignore quota */
  }
}

function clipDetail(detail?: string | null) {
  if (!detail) return null;
  const text = detail.trim();
  if (text.length <= 22) return text;
  return `${text.slice(0, 20)}…`;
}

function Cover({ src, alt }: { src: string | null; alt: string }) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) {
    return (
      <div className="flex h-24 w-20 shrink-0 items-center justify-center rounded-xl bg-bar text-bar-fg">
        <Play className="size-7" aria-hidden="true" />
      </div>
    );
  }
  return (
    <img
      src={mediaHref(src, "cover.jpg", true)}
      alt={alt}
      className="h-24 w-20 shrink-0 rounded-xl bg-bar object-cover"
      onError={() => setFailed(true)}
    />
  );
}

function SaveButton({
  href,
  label,
  detail,
}: {
  href: string;
  label: string;
  detail?: string | null;
}) {
  const extra = clipDetail(detail);
  return (
    <a
      href={href}
      className="neon-btn flex min-h-12 w-full min-w-0 max-w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-accent px-4 text-base font-semibold text-accent-ink transition-colors hover:bg-accent-hover"
    >
      <Download className="size-5 shrink-0" aria-hidden="true" />
      <span className="min-w-0 truncate">
        {label}
        {extra ? <span className="font-medium"> · {extra}</span> : null}
      </span>
    </a>
  );
}

function LivePhotoButton({
  still,
  motion,
  filename,
  compact = false,
}: {
  still: string;
  motion: string;
  filename: string;
  compact?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save() {
    setBusy(true);
    setError(null);
    try {
      const q = new URLSearchParams({ still, motion, name: filename });
      const res = await fetch(`/api/live?${q}`);
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as { error?: string } | null;
        setError(data?.error || "Couldn't build that Live Photo.");
        return;
      }
      const blob = await res.blob();
      const href = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = href;
      link.download = filename.endsWith(".jpg") ? filename : `${filename}.jpg`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(href);
    } catch {
      setError("Couldn't build that Live Photo.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-1">
      <button
        type="button"
        onClick={() => void save()}
        disabled={busy}
        className={
          compact
            ? "flex min-h-11 w-full items-center justify-center rounded-lg border border-line bg-surface px-2 text-xs font-semibold text-ink"
            : "neon-btn flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 text-base font-semibold text-accent-ink disabled:opacity-60"
        }
      >
        {busy ? (
          <Loader2 className="size-4 animate-spin" aria-hidden="true" />
        ) : compact ? null : (
          <ImageIcon className="size-5 shrink-0" aria-hidden="true" />
        )}
        {busy ? "Building…" : compact ? "Live Photo" : "Download Live Photo"}
      </button>
      {compact ? null : (
        <p className="px-1 text-center text-xs text-faint">Saves as a photo, not a video. No watermark.</p>
      )}
      {error ? <p className="px-1 text-center text-xs text-danger">{error}</p> : null}
    </div>
  );
}

export function Downloader() {
  const inputId = useId();
  const fieldRef = useRef<HTMLInputElement>(null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [media, setMedia] = useState<ResolvedMedia | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    setHistory(readHistory());
  }, []);

  async function resolve(raw: string) {
    const target = parseTikTokTarget(raw);
    if (!target) {
      setError("Paste a TikTok video, live photo, or profile link.");
      setMedia(null);
      return;
    }
    const url = target.type === "profile" ? `@${target.handle}` : target.url;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const data = (await res.json()) as { media?: ResolvedMedia; error?: string };
      if (!res.ok || !data.media) {
        setMedia(null);
        setError(data.error || "Couldn't download that post.");
        return;
      }
      setMedia(data.media);
      setInput(url);
      const next: HistoryItem[] = [
        {
          url,
          title: data.media.title,
          handle: data.media.authorHandle,
          at: Date.now(),
        },
        ...readHistory().filter((item) => item.url !== url),
      ].slice(0, 6);
      writeHistory(next);
      setHistory(next);
    } catch {
      setMedia(null);
      setError("Network problem. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setMedia(null);
    setError(null);
    setInput("");
    fieldRef.current?.focus();
  }

  async function pasteClipboard() {
    try {
      const text = await navigator.clipboard.readText();
      setInput(text);
      setError(null);
      fieldRef.current?.focus();
    } catch {
      setError("Clipboard is blocked here. Long-press the box and paste the link.");
    }
  }

  const slug = media ? fileSlug(media.authorHandle, media.id) : "aiden-knox";
  const duration = media ? formatDuration(media.durationSec) : null;
  const standardHref = media?.videoUrl ? mediaHref(media.videoUrl, `${slug}.mp4`) : null;
  const hdHref = media?.hdUrl ? mediaHref(media.hdUrl, `${slug}-hd.mp4`) : null;
  const audioHref = media?.audioUrl ? mediaHref(media.audioUrl, `${slug}.mp3`) : null;
  const avatarHref = media?.avatarUrl
    ? mediaHref(media.avatarUrl, `${fileSlug(media.authorHandle, "avatar")}.jpg`)
    : null;
  const profileLabel = media?.avatarIsHd ? "Download profile picture HD" : "Download profile picture";

  return (
    <div className="flex min-w-0 flex-col gap-4">
      <form
        className="flex flex-col gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          void resolve(input);
        }}
      >
        <label htmlFor={inputId} className="text-sm font-medium text-ink">
          TikTok link
        </label>
        <div className="flex min-w-0 flex-col gap-2">
          <input
            ref={fieldRef}
            id={inputId}
            name="url"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Video, live photo, or @username"
            autoComplete="off"
            spellCheck={false}
            className="min-h-12 w-full min-w-0 flex-1 rounded-xl border border-line bg-surface px-4 text-base text-ink outline-none placeholder:text-faint focus-visible:border-accent"
          />
          <button
            type="button"
            onClick={() => void pasteClipboard()}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm font-semibold text-ink hover:bg-surface-2"
          >
            <ClipboardPaste className="size-4" aria-hidden="true" />
            Paste
          </button>
        </div>
        <div className="flex flex-col gap-2">
          <button
            type="submit"
            disabled={busy}
            className="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-bar px-4 text-base font-semibold text-bar-fg disabled:opacity-60"
          >
            {busy ? (
              <Loader2 className="size-5 animate-spin" aria-hidden="true" />
            ) : (
              <Download className="size-5" aria-hidden="true" />
            )}
            {busy ? "Looking up…" : "Get download"}
          </button>
          <button
            type="button"
            onClick={() => void resolve(SAMPLE_URL)}
            disabled={busy}
            className="inline-flex min-h-12 items-center justify-center rounded-xl border border-line bg-surface px-4 text-sm font-semibold text-ink hover:bg-surface-2 disabled:opacity-60"
          >
            Try a sample
          </button>
        </div>
      </form>

      {error ? (
        <p role="alert" className="rounded-xl bg-danger-bg px-4 py-3 text-sm text-danger">
          {error}
        </p>
      ) : null}

      {media ? (
        <section className="rise overflow-hidden rounded-2xl border border-line bg-surface" aria-live="polite">
          <div className="flex gap-3 p-4">
            <Cover src={media.cover} alt="" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold tracking-wide text-accent">No watermark</p>
              <h2 className="mt-1 line-clamp-4 break-words text-sm font-semibold leading-snug text-ink">
                {media.title}
              </h2>
              <p className="mt-1 truncate text-sm text-muted">
                {media.authorHandle ? `@${media.authorHandle}` : media.authorName}
                {duration ? ` · ${duration}` : ""}
                {media.kind === "photo" ? ` · ${media.photos.length} photos` : ""}
                {media.kind === "live" ? " · Live Photo" : ""}
                {media.kind === "profile" ? " · Profile" : ""}
              </p>
              <div className="mt-2 flex flex-wrap gap-3 text-xs text-faint">
                {formatCount(media.plays) ? (
                  <span className="inline-flex items-center gap-1">
                    <Eye className="size-3.5" aria-hidden="true" />
                    {formatCount(media.plays)}
                  </span>
                ) : null}
                {formatCount(media.likes) ? (
                  <span className="inline-flex items-center gap-1">
                    <Heart className="size-3.5" aria-hidden="true" />
                    {formatCount(media.likes)}
                  </span>
                ) : null}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2 px-3 pb-3">
            {media.liveStill && media.liveMotion ? (
              <LivePhotoButton
                still={media.liveStill}
                motion={media.liveMotion}
                filename={`${slug}-live-photo.jpg`}
              />
            ) : null}
            {media.kind !== "profile" && standardHref ? (
              <SaveButton href={standardHref} label="Download MP4" />
            ) : null}
            {media.kind !== "profile" && hdHref ? (
              <SaveButton href={hdHref} label="Download MP4 HD" />
            ) : null}
            {media.kind !== "profile" && standardHref && !hdHref && media.kind !== "live" ? (
              <p className="px-1 text-center text-xs text-faint">
                HD source wasn’t published for this post. MP4 is the clean, no-watermark file.
              </p>
            ) : null}
            {media.kind !== "profile" && audioHref ? (
              <SaveButton href={audioHref} label="Download MP3" />
            ) : null}
            {avatarHref ? <SaveButton href={avatarHref} label={profileLabel} /> : null}
            {media.photos.length > 0 ? (
              <div className="mt-1 flex flex-col gap-2">
                <p className="flex items-center gap-2 px-1 text-sm font-semibold text-ink">
                  <ImageIcon className="size-4" aria-hidden="true" />
                  Photos, no watermark
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {media.photos.map((photo, index) => (
                    <div key={photo.url} className="flex flex-col gap-1">
                      <a
                        href={mediaHref(photo.url, `${slug}-photo-${index + 1}.jpg`)}
                        className="relative aspect-square overflow-hidden rounded-xl bg-surface-2"
                      >
                        <img
                          src={mediaHref(photo.url, `photo-${index + 1}.jpg`, true)}
                          alt={`Photo ${index + 1}`}
                          className="h-full w-full object-cover"
                        />
                        <span className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1 bg-bar/90 py-1.5 text-xs font-semibold text-bar-fg">
                          <Download className="size-3.5" aria-hidden="true" />
                          {index + 1}
                        </span>
                      </a>
                      {photo.motion ? (
                        <LivePhotoButton
                          still={photo.url}
                          motion={photo.motion}
                          filename={`${slug}-live-${index + 1}.jpg`}
                          compact
                        />
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
          </div>

          <button
            type="button"
            onClick={reset}
            className="flex min-h-12 w-full items-center justify-center gap-2 bg-bg text-base font-medium text-ink"
          >
            <RotateCcw className="size-4" aria-hidden="true" />
            Download more videos
          </button>
        </section>
      ) : (
        <div className="rounded-2xl border border-dashed border-line bg-surface px-4 py-6 text-center">
          <Music className="mx-auto size-5 text-faint" aria-hidden="true" />
          <p className="mt-2 text-sm text-muted">
            Video, live photo, sound, photos, and HD profile pictures show up here.
          </p>
        </div>
      )}

      <a
        href="#how"
        className="flex min-h-12 items-center gap-2 rounded-2xl border border-line bg-surface px-4 text-sm font-medium text-accent"
      >
        <Lightbulb className="size-4 shrink-0" aria-hidden="true" />
        How to save TikTok video no watermark?
      </a>

      {history.length > 0 ? (
        <div>
          <h3 className="text-sm font-semibold text-ink">Recent</h3>
          <ul className="mt-2 flex flex-col gap-2">
            {history.map((item) => (
              <li key={item.url}>
                <button
                  type="button"
                  onClick={() => void resolve(item.url)}
                  disabled={busy}
                  className="flex w-full min-w-0 flex-col rounded-xl border border-line bg-surface px-3 py-2 text-left hover:bg-surface-2 disabled:opacity-60"
                >
                  <span className="truncate text-sm font-medium text-ink">{item.title}</span>
                  <span className="truncate text-xs text-faint">
                    {item.handle ? `@${item.handle}` : item.url}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
