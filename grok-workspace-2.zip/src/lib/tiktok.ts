export const SAMPLE_URL = "https://www.tiktok.com/@tiktok/video/7106594312292453675";

const TIKTOK_HOST = /^(?:(?:www|m|vm|vt|us|t|vmweb)\.)?tiktok\.com$/i;

export function normalizeTikTokUrl(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed || trimmed.length > 2000) return null;
  const found = trimmed.match(/https?:\/\/[^\s<>"']+/i);
  let raw = (found ? found[0] : trimmed).replace(/[),.;]+$/, "");
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  if (!TIKTOK_HOST.test(url.hostname)) return null;
  url.protocol = "https:";
  url.hash = "";
  return url.toString();
}

export function parseTikTokTarget(
  input: string,
): { type: "post"; url: string } | { type: "profile"; handle: string } | null {
  const trimmed = input.trim();
  const at = trimmed.match(/^@([A-Za-z0-9._]{2,24})$/);
  if (at) return { type: "profile", handle: at[1] };
  const url = normalizeTikTokUrl(trimmed);
  if (!url) return null;
  const parts = new URL(url).pathname.split("/").filter(Boolean);
  if (parts.length === 1 && parts[0].startsWith("@") && parts[0].length > 1) {
    const handle = parts[0].slice(1);
    if (!/^[A-Za-z0-9._]{2,24}$/.test(handle)) return null;
    return { type: "profile", handle };
  }
  return { type: "post", url };
}

export type PhotoSlide = {
  url: string;
  motion: string | null;
};

export type ResolvedMedia = {
  id: string;
  sourceUrl: string;
  kind: "video" | "photo" | "live" | "profile";
  title: string;
  authorName: string;
  authorHandle: string;
  cover: string | null;
  durationSec: number | null;
  plays: number | null;
  likes: number | null;
  videoUrl: string | null;
  videoBytes: number | null;
  hdUrl: string | null;
  hdBytes: number | null;
  audioUrl: string | null;
  audioTitle: string | null;
  photos: PhotoSlide[];
  avatarUrl: string | null;
  avatarIsHd: boolean;
  liveStill: string | null;
  liveMotion: string | null;
};

export function formatBytes(n: number | null): string | null {
  if (!n || n <= 0) return null;
  if (n < 1024 * 1024) return `${Math.max(1, Math.round(n / 1024))} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatDuration(sec: number | null): string | null {
  if (!sec || sec <= 0) return null;
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function formatCount(n: number | null): string | null {
  if (n == null || n < 0) return null;
  return new Intl.NumberFormat("en", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(n);
}

export function fileSlug(handle: string, id: string): string {
  const who = handle
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 24);
  const post = id.replace(/[^a-z0-9]/gi, "").slice(0, 12);
  return ["aiden-knox", who || "tiktok", post].filter(Boolean).join("-");
}

export function mediaHref(src: string, filename: string, inline = false): string {
  const q = new URLSearchParams({
    src,
    name: filename,
  });
  if (inline) q.set("disp", "inline");
  return `/api/media?${q.toString()}`;
}
