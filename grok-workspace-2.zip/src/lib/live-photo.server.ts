const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n += 1) {
  let c = n;
  for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  CRC_TABLE[n] = c >>> 0;
}

function crc32(data: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < data.length; i += 1) c = CRC_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function concat(parts: Uint8Array[]): Uint8Array {
  const len = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(len);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

function u16le(n: number): Uint8Array {
  const b = new Uint8Array(2);
  new DataView(b.buffer).setUint16(0, n, true);
  return b;
}

function u32le(n: number): Uint8Array {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setUint32(0, n, true);
  return b;
}

function u16be(n: number): Uint8Array {
  const b = new Uint8Array(2);
  new DataView(b.buffer).setUint16(0, n, false);
  return b;
}

function u32be(n: number): Uint8Array {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setUint32(0, n, false);
  return b;
}

function ascii(text: string): Uint8Array {
  return new TextEncoder().encode(text);
}

export function zipStore(files: { name: string; data: Uint8Array }[]): Uint8Array {
  const locals: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;
  for (const file of files) {
    const name = ascii(file.name);
    const crc = crc32(file.data);
    const local = concat([
      u32le(0x04034b50),
      u16le(20),
      u16le(0),
      u16le(0),
      u16le(0),
      u16le(0),
      u32le(crc),
      u32le(file.data.length),
      u32le(file.data.length),
      u16le(name.length),
      u16le(0),
      name,
      file.data,
    ]);
    locals.push(local);
    central.push(
      concat([
        u32le(0x02014b50),
        u16le(20),
        u16le(20),
        u16le(0),
        u16le(0),
        u16le(0),
        u16le(0),
        u32le(crc),
        u32le(file.data.length),
        u32le(file.data.length),
        u16le(name.length),
        u16le(0),
        u16le(0),
        u16le(0),
        u16le(0),
        u32le(0),
        u32le(offset),
        name,
      ]),
    );
    offset += local.length;
  }
  const directory = concat(central);
  const end = concat([
    u32le(0x06054b50),
    u16le(0),
    u16le(0),
    u16le(files.length),
    u16le(files.length),
    u32le(directory.length),
    u32le(offset),
    u16le(0),
  ]);
  return concat([...locals, directory, end]);
}

function xmpPacket(videoLength: number): Uint8Array {
  const xml = `<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="0"
    GCamera:MicroVideo="1"
    GCamera:MicroVideoVersion="1"
    GCamera:MicroVideoOffset="${videoLength}">
   <Container:Directory>
    <rdf:Seq>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary"/>
     </rdf:li>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${videoLength}"/>
     </rdf:li>
    </rdf:Seq>
   </Container:Directory>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>`;
  return new TextEncoder().encode(xml);
}

function app1(header: string, payload: Uint8Array): Uint8Array {
  const head = ascii(header);
  const body = concat([head, payload]);
  return concat([new Uint8Array([0xff, 0xe1]), u16be(body.length + 2), body]);
}

function insertAfterSoi(jpeg: Uint8Array, segment: Uint8Array): Uint8Array {
  if (jpeg.length < 2 || jpeg[0] !== 0xff || jpeg[1] !== 0xd8) {
    throw new Error("The still image is not a JPEG.");
  }
  return concat([jpeg.subarray(0, 2), segment, jpeg.subarray(2)]);
}

export function isMp4(data: Uint8Array): boolean {
  return data.length > 12 && asciiDecode(data.subarray(4, 8)) === "ftyp";
}

function asciiDecode(data: Uint8Array): string {
  return String.fromCharCode(...data);
}

/** A JPEG that still opens as a photo, with the motion clip tucked inside. */
export function motionJpeg(jpeg: Uint8Array, video: Uint8Array): Uint8Array {
  if (!isMp4(video)) throw new Error("The motion clip is not a video file.");
  const segment = app1("http://ns.adobe.com/xap/1.0/\0", xmpPacket(video.length));
  return concat([insertAfterSoi(jpeg, segment), video]);
}

function appleMakerNote(uuid: string): Uint8Array {
  const id = ascii(uuid);
  return concat([
    ascii("Apple iOS"),
    new Uint8Array([0, 0, 1]),
    ascii("MM"),
    new Uint8Array([0, 1, 0, 0x11, 0, 2]),
    u32be(id.length + 1),
    u32be(32),
    new Uint8Array(4),
    id,
    new Uint8Array([0]),
  ]);
}

function exifEntry(tag: number, type: number, count: number, value: number): Uint8Array {
  return concat([u16be(tag), u16be(type), u32be(count), u32be(value)]);
}

function exifWithMakerNote(uuid: string): Uint8Array {
  const note = appleMakerNote(uuid);
  const make = concat([ascii("Apple"), new Uint8Array([0])]);
  const model = concat([ascii("iPhone"), new Uint8Array([0])]);
  const ifdCount = 3;
  const ifdStart = 8;
  const dataStart = ifdStart + 2 + ifdCount * 12 + 4;
  const makeAt = dataStart;
  const modelAt = makeAt + make.length;
  const noteAt = modelAt + model.length;
  const tiff = concat([
    ascii("MM"),
    u16be(42),
    u32be(ifdStart),
    u16be(ifdCount),
    exifEntry(0x010f, 2, make.length, makeAt),
    exifEntry(0x0110, 2, model.length, modelAt),
    exifEntry(0x927c, 7, note.length, noteAt),
    u32be(0),
    make,
    model,
    note,
  ]);
  return app1("Exif\0\0", tiff);
}

export function jpegWithContentId(jpeg: Uint8Array, uuid: string): Uint8Array {
  return insertAfterSoi(jpeg, exifWithMakerNote(uuid));
}

function atom(type: string, body: Uint8Array): Uint8Array {
  return concat([u32be(8 + body.length), ascii(type), body]);
}

function contentIdentifierMeta(uuid: string): Uint8Array {
  const id = ascii(uuid);
  const hdlr = atom(
    "hdlr",
    concat([
      new Uint8Array(4),
      new Uint8Array(4),
      ascii("mdta"),
      new Uint8Array(12),
      new Uint8Array(2),
    ]),
  );
  const keyEntry = concat([u32be(8 + "com.apple.quicktime.content.identifier".length), ascii("mdta"), ascii("com.apple.quicktime.content.identifier")]);
  const keys = atom("keys", concat([new Uint8Array(4), u32be(1), keyEntry]));
  const data = atom("data", concat([u32be(1), u32be(0), id]));
  const item = atom("\u0000\u0000\u0000\u0001", data);
  return atom("meta", concat([hdlr, keys, atom("ilst", item)]));
}

function readU32(data: Uint8Array, offset: number): number {
  return new DataView(data.buffer, data.byteOffset, data.byteLength).getUint32(offset);
}

/** Tag the clip with the same asset id when the moov atom sits after the media. */
export function tagMov(video: Uint8Array, uuid: string): Uint8Array {
  if (!isMp4(video)) return video;
  const top: { type: string; start: number; size: number }[] = [];
  let offset = 0;
  while (offset + 8 <= video.length) {
    const size = readU32(video, offset);
    if (size < 8 || offset + size > video.length) break;
    top.push({ type: asciiDecode(video.subarray(offset + 4, offset + 8)), start: offset, size });
    offset += size;
  }
  const moov = top.find((item) => item.type === "moov");
  const mdat = top.find((item) => item.type === "mdat");
  if (!moov || !mdat || moov.start < mdat.start) return video;
  const meta = contentIdentifierMeta(uuid);
  const next = new Uint8Array(video.length + meta.length);
  const insertAt = moov.start + moov.size;
  next.set(video.subarray(0, insertAt), 0);
  next.set(meta, insertAt);
  next.set(video.subarray(insertAt), insertAt + meta.length);
  const view = new DataView(next.buffer);
  view.setUint32(moov.start, moov.size + meta.length);
  return next;
}

export function assetId(): string {
  return crypto.randomUUID().toUpperCase();
}

export function livePhotoZip(still: Uint8Array, motion: Uint8Array): Uint8Array {
  const id = assetId();
  const photo = jpegWithContentId(still, id);
  const clip = tagMov(motion, id);
  return zipStore([
    { name: "IMG.jpg", data: photo },
    { name: "IMG.mov", data: clip },
  ]);
}
