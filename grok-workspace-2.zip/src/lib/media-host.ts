const ALLOWED_HOST =
  /(^|\.)((tiktokcdn(-us|-eu)?|tiktokv|muscdn|musical\.ly|ibyteimg|byteimg|byteoversea|byteicdn|tikwm|ttwstatic)\.com)$/i;

export function isAllowedMediaHost(hostname: string): boolean {
  return ALLOWED_HOST.test(hostname);
}

export function parseMediaUrl(raw: string): URL | null {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.protocol !== "https:") return null;
  if (!isAllowedMediaHost(url.hostname)) return null;
  return url;
}
