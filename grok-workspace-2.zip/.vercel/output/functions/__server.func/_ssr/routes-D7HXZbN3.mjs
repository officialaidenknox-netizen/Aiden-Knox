import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LoaderCircle, c as Heart, d as ClipboardPaste, i as Music, l as Eye, n as RotateCcw, o as Lightbulb, r as Play, s as Image, u as Download } from "../_libs/lucide-react.mjs";
import { a as formatDuration, i as formatCount, n as SAMPLE_URL, o as mediaHref, r as fileSlug, s as parseTikTokTarget } from "./router-BTU0uH4P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D7HXZbN3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HISTORY_KEY = "aiden-knox-history";
function readHistory() {
	try {
		const raw = localStorage.getItem(HISTORY_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((item) => !!item && typeof item === "object" && typeof item.url === "string" && typeof item.title === "string");
	} catch {
		return [];
	}
}
function writeHistory(items) {
	try {
		localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 6)));
	} catch {}
}
function clipDetail(detail) {
	if (!detail) return null;
	const text = detail.trim();
	if (text.length <= 22) return text;
	return `${text.slice(0, 20)}…`;
}
function Cover({ src, alt }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (!src || failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-24 w-20 shrink-0 items-center justify-center rounded-xl bg-bar text-bar-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
			className: "size-7",
			"aria-hidden": "true"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: mediaHref(src, "cover.jpg", true),
		alt,
		className: "h-24 w-20 shrink-0 rounded-xl bg-bar object-cover",
		onError: () => setFailed(true)
	});
}
function SaveButton({ href, label, detail }) {
	const extra = clipDetail(detail);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href,
		className: "neon-btn flex min-h-12 w-full min-w-0 max-w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-accent px-4 text-base font-semibold text-accent-ink transition-colors hover:bg-accent-hover",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
			className: "size-5 shrink-0",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 truncate",
			children: [label, extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-medium",
				children: [" · ", extra]
			}) : null]
		})]
	});
}
function LivePhotoButton({ still, motion, filename, compact = false }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function save() {
		setBusy(true);
		setError(null);
		try {
			const q = new URLSearchParams({
				still,
				motion,
				name: filename
			});
			const res = await fetch(`/api/live?${q}`);
			if (!res.ok) {
				const data = await res.json().catch(() => null);
				setError(data?.error || "Couldn't build that Live Photo.");
				return;
			}
			const blob = await res.blob();
			const href = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = href;
			link.download = filename.endsWith(".jpg") ? filename : `${filename}.jpg`;
			document.body.appendChild(link);
			link.click();
			link.remove();
			URL.revokeObjectURL(href);
		} catch {
			setError("Couldn't build that Live Photo.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => void save(),
				disabled: busy,
				className: compact ? "flex min-h-11 w-full items-center justify-center rounded-lg border border-line bg-surface px-2 text-xs font-semibold text-ink" : "neon-btn flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 text-base font-semibold text-accent-ink disabled:opacity-60",
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					className: "size-4 animate-spin",
					"aria-hidden": "true"
				}) : compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
					className: "size-5 shrink-0",
					"aria-hidden": "true"
				}), busy ? "Building…" : compact ? "Live Photo" : "Download Live Photo"]
			}),
			compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-center text-xs text-faint",
				children: "Saves as a photo, not a video. No watermark."
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-center text-xs text-danger",
				children: error
			}) : null
		]
	});
}
function Downloader() {
	const inputId = (0, import_react.useId)();
	const fieldRef = (0, import_react.useRef)(null);
	const [input, setInput] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [media, setMedia] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setHistory(readHistory());
	}, []);
	async function resolve(raw) {
		const target = parseTikTokTarget(raw);
		if (!target) {
			setError("Paste a TikTok video, live photo, or profile link.");
			setMedia(null);
			return;
		}
		const url = target.type === "profile" ? `@${target.handle}` : target.url;
		setBusy(true);
		setError(null);
		try {
			const res = await fetch("/api/resolve", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ url })
			});
			const data = await res.json();
			if (!res.ok || !data.media) {
				setMedia(null);
				setError(data.error || "Couldn't download that post.");
				return;
			}
			setMedia(data.media);
			setInput(url);
			const next = [{
				url,
				title: data.media.title,
				handle: data.media.authorHandle,
				at: Date.now()
			}, ...readHistory().filter((item) => item.url !== url)].slice(0, 6);
			writeHistory(next);
			setHistory(next);
		} catch {
			setMedia(null);
			setError("Network problem. Check your connection and try again.");
		} finally {
			setBusy(false);
		}
	}
	function reset() {
		setMedia(null);
		setError(null);
		setInput("");
		fieldRef.current?.focus();
	}
	async function pasteClipboard() {
		try {
			const text = await navigator.clipboard.readText();
			setInput(text);
			setError(null);
			fieldRef.current?.focus();
		} catch {
			setError("Clipboard is blocked here. Long-press the box and paste the link.");
		}
	}
	const slug = media ? fileSlug(media.authorHandle, media.id) : "aiden-knox";
	const duration = media ? formatDuration(media.durationSec) : null;
	const standardHref = media?.videoUrl ? mediaHref(media.videoUrl, `${slug}.mp4`) : null;
	const hdHref = media?.hdUrl ? mediaHref(media.hdUrl, `${slug}-hd.mp4`) : null;
	const audioHref = media?.audioUrl ? mediaHref(media.audioUrl, `${slug}.mp3`) : null;
	const avatarHref = media?.avatarUrl ? mediaHref(media.avatarUrl, `${fileSlug(media.authorHandle, "avatar")}.jpg`) : null;
	const profileLabel = media?.avatarIsHd ? "Download profile picture HD" : "Download profile picture";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (e) => {
					e.preventDefault();
					resolve(input);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: inputId,
						className: "text-sm font-medium text-ink",
						children: "TikTok link"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fieldRef,
							id: inputId,
							name: "url",
							value: input,
							onChange: (e) => setInput(e.target.value),
							placeholder: "Video, live photo, or @username",
							autoComplete: "off",
							spellCheck: false,
							className: "min-h-12 w-full min-w-0 flex-1 rounded-xl border border-line bg-surface px-4 text-base text-ink outline-none placeholder:text-faint focus-visible:border-accent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => void pasteClipboard(),
							className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm font-semibold text-ink hover:bg-surface-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Paste"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: busy,
							className: "inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-bar px-4 text-base font-semibold text-bar-fg disabled:opacity-60",
							children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "size-5 animate-spin",
								"aria-hidden": "true"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-5",
								"aria-hidden": "true"
							}), busy ? "Looking up…" : "Get download"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void resolve(SAMPLE_URL),
							disabled: busy,
							className: "inline-flex min-h-12 items-center justify-center rounded-xl border border-line bg-surface px-4 text-sm font-semibold text-ink hover:bg-surface-2 disabled:opacity-60",
							children: "Try a sample"
						})]
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "rounded-xl bg-danger-bg px-4 py-3 text-sm text-danger",
				children: error
			}) : null,
			media ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise overflow-hidden rounded-2xl border border-line bg-surface",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
							src: media.cover,
							alt: ""
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-wide text-accent",
									children: "No watermark"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 line-clamp-4 break-words text-sm font-semibold leading-snug text-ink",
									children: media.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 truncate text-sm text-muted",
									children: [
										media.authorHandle ? `@${media.authorHandle}` : media.authorName,
										duration ? ` · ${duration}` : "",
										media.kind === "photo" ? ` · ${media.photos.length} photos` : "",
										media.kind === "live" ? " · Live Photo" : "",
										media.kind === "profile" ? " · Profile" : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap gap-3 text-xs text-faint",
									children: [formatCount(media.plays) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {
											className: "size-3.5",
											"aria-hidden": "true"
										}), formatCount(media.plays)]
									}) : null, formatCount(media.likes) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
											className: "size-3.5",
											"aria-hidden": "true"
										}), formatCount(media.likes)]
									}) : null]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 px-3 pb-3",
						children: [
							media.liveStill && media.liveMotion ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LivePhotoButton, {
								still: media.liveStill,
								motion: media.liveMotion,
								filename: `${slug}-live-photo.jpg`
							}) : null,
							media.kind !== "profile" && standardHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, {
								href: standardHref,
								label: "Download MP4"
							}) : null,
							media.kind !== "profile" && hdHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, {
								href: hdHref,
								label: "Download MP4 HD"
							}) : null,
							media.kind !== "profile" && standardHref && !hdHref && media.kind !== "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-1 text-center text-xs text-faint",
								children: "HD source wasn’t published for this post. MP4 is the clean, no-watermark file."
							}) : null,
							media.kind !== "profile" && audioHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, {
								href: audioHref,
								label: "Download MP3"
							}) : null,
							avatarHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, {
								href: avatarHref,
								label: profileLabel
							}) : null,
							media.photos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 px-1 text-sm font-semibold text-ink",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Photos, no watermark"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-3 gap-2",
									children: media.photos.map((photo, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: mediaHref(photo.url, `${slug}-photo-${index + 1}.jpg`),
											className: "relative aspect-square overflow-hidden rounded-xl bg-surface-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: mediaHref(photo.url, `photo-${index + 1}.jpg`, true),
												alt: `Photo ${index + 1}`,
												className: "h-full w-full object-cover"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "absolute inset-x-0 bottom-0 flex items-center justify-center gap-1 bg-bar/90 py-1.5 text-xs font-semibold text-bar-fg",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
													className: "size-3.5",
													"aria-hidden": "true"
												}), index + 1]
											})]
										}), photo.motion ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LivePhotoButton, {
											still: photo.url,
											motion: photo.motion,
											filename: `${slug}-live-${index + 1}.jpg`,
											compact: true
										}) : null]
									}, photo.url))
								})]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: reset,
						className: "flex min-h-12 w-full items-center justify-center gap-2 bg-bg text-base font-medium text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Download more videos"]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-dashed border-line bg-surface px-4 py-6 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, {
					className: "mx-auto size-5 text-faint",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Video, live photo, sound, photos, and HD profile pictures show up here."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "#how",
				className: "flex min-h-12 items-center gap-2 rounded-2xl border border-line bg-surface px-4 text-sm font-medium text-accent",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, {
					className: "size-4 shrink-0",
					"aria-hidden": "true"
				}), "How to save TikTok video no watermark?"]
			}),
			history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-semibold text-ink",
				children: "Recent"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-col gap-2",
				children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void resolve(item.url),
					disabled: busy,
					className: "flex w-full min-w-0 flex-col rounded-xl border border-line bg-surface px-3 py-2 text-left hover:bg-surface-2 disabled:opacity-60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-sm font-medium text-ink",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-xs text-faint",
						children: item.handle ? `@${item.handle}` : item.url
					})]
				}) }, item.url))
			})] }) : null
		]
	});
}
function GlowField() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce), (pointer: coarse), (max-width: 900px)").matches;
		if (reduce) return;
		let frame = 0;
		let alive = true;
		const sparks = [];
		function resize() {
			const dpr = window.innerWidth < 720 ? 1 : Math.min(window.devicePixelRatio || 1, 1.5);
			canvas.width = Math.floor(window.innerWidth * dpr);
			canvas.height = Math.floor(window.innerHeight * dpr);
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		}
		function seed() {
			sparks.length = 0;
			const count = window.innerWidth < 720 ? 14 : 28;
			for (let i = 0; i < count; i += 1) sparks.push({
				x: Math.random() * window.innerWidth,
				y: Math.random() * window.innerHeight,
				r: Math.random() < .15 ? 1.6 : .7 + Math.random() * .7,
				v: .12 + Math.random() * .28,
				a: .35 + Math.random() * .5,
				tw: Math.random() * Math.PI * 2
			});
		}
		function draw(time) {
			if (!alive) return;
			if (document.hidden) {
				frame = window.requestAnimationFrame(draw);
				return;
			}
			const w = window.innerWidth;
			const h = window.innerHeight;
			ctx.clearRect(0, 0, w, h);
			for (const spark of sparks) {
				if (!reduce) {
					spark.y -= spark.v;
					spark.tw += .015;
					if (spark.y < -8) {
						spark.y = h + 8;
						spark.x = Math.random() * w;
					}
				}
				const alpha = spark.a * (.7 + .3 * Math.sin(spark.tw + time / 900));
				ctx.fillStyle = `rgba(255,255,255,${alpha})`;
				ctx.beginPath();
				ctx.arc(spark.x, spark.y, spark.r, 0, Math.PI * 2);
				ctx.fill();
			}
			if (!reduce) frame = window.requestAnimationFrame(draw);
		}
		resize();
		seed();
		frame = window.requestAnimationFrame(draw);
		const onResize = () => {
			resize();
			seed();
		};
		window.addEventListener("resize", onResize);
		return () => {
			alive = false;
			window.cancelAnimationFrame(frame);
			window.removeEventListener("resize", onResize);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		"aria-hidden": "true",
		className: "pointer-events-none fixed inset-0 z-0 h-full w-full max-w-full"
	});
}
var STEPS = [
	{
		n: "1",
		title: "Copy the share link",
		body: "In TikTok, open Share and choose Copy link. Videos and photo posts both work, including vm.tiktok.com shorts."
	},
	{
		n: "2",
		title: "Paste it into Aiden Knox",
		body: "Drop the link in the box and tap Get download. Private or deleted posts can’t be fetched."
	},
	{
		n: "3",
		title: "Save the clean file",
		body: "Pick MP4, MP4 HD, a Live Photo, MP3, or an HD profile picture. Watermarked copies are never offered."
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen overflow-x-clip",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowField, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-20 border-b border-line bg-bg/90",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#top",
							className: "flex min-w-0 items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/aiden-pfp.jpg",
								alt: "",
								className: "pfp-mini"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate font-display text-lg font-semibold tracking-tight text-ink",
								children: "Aiden Knox"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#how",
							className: "shrink-0 text-sm font-semibold text-ink",
							children: "How it works"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					id: "top",
					className: "mx-auto w-full max-w-md px-3 py-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "neon-card min-w-0 rounded-2xl border border-line bg-surface-2 p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Downloader, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "how",
					className: "scroll-mt-16 border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-md px-4 py-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-semibold tracking-tight text-ink",
							children: "How to save a TikTok video with no watermark"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-5 flex flex-col gap-3",
							children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-2xl border border-line bg-surface p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-8 items-center justify-center rounded-full bg-bar text-sm font-semibold text-bar-fg",
										children: step.n
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-3 text-base font-semibold text-ink",
										children: step.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: step.body
									})
								]
							}, step.n))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-md px-4 py-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-semibold tracking-tight text-ink",
							children: "Questions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
									className: "rounded-2xl border border-line bg-surface px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
										className: "cursor-pointer text-base font-semibold text-ink",
										children: "Is the TikTok watermark removed?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: "Yes. Download MP4 and Download MP4 HD are the files without the platform watermark. Aiden Knox does not offer the watermarked version."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
									className: "rounded-2xl border border-line bg-surface px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
										className: "cursor-pointer text-base font-semibold text-ink",
										children: "When is HD available?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: "HD appears when TikTok published a higher-quality source. If it didn’t, you still get the clean MP4."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
									className: "rounded-2xl border border-line bg-surface px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
										className: "cursor-pointer text-base font-semibold text-ink",
										children: "Is a Live Photo a video file?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: "No. Download Live Photo saves one JPEG photo with the motion inside it, without the watermark. It does not save an MP4."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
									className: "rounded-2xl border border-line bg-surface px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
										className: "cursor-pointer text-base font-semibold text-ink",
										children: "How do I get a profile picture in HD?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: "Paste a profile link or @username, or download any of their posts. Download profile picture HD uses the largest portrait TikTok published."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
									className: "rounded-2xl border border-line bg-surface px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
										className: "cursor-pointer text-base font-semibold text-ink",
										children: "What am I allowed to download?"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: "Only public posts you have the right to save. Aiden Knox is for personal copies — credit creators if you share their work again."
									})]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-md flex-col gap-1 px-4 py-6 text-sm text-faint",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-base text-ink",
							children: "Aiden Knox"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Public TikTok posts only. Not affiliated with TikTok." })]
					})
				})
			]
		})]
	});
}
//#endregion
export { Home as component };
