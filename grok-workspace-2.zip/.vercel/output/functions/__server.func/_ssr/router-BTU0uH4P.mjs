import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BTU0uH4P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-DN_KhHCu.css";
var APP_NAME = "Aiden Knox";
var Route$4 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Aiden Knox downloads public TikTok videos, Live Photos, and HD profile pictures without the watermark."
			},
			{
				name: "theme-color",
				content: "#050505"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Unbounded:wght@500;600;700&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-D7HXZbN3.mjs");
var Route$3 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var CRC_TABLE = /* @__PURE__ */ new Uint32Array(256);
for (let n = 0; n < 256; n += 1) {
	let c = n;
	for (let k = 0; k < 8; k += 1) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
	CRC_TABLE[n] = c >>> 0;
}
function concat(parts) {
	const len = parts.reduce((sum, part) => sum + part.length, 0);
	const out = new Uint8Array(len);
	let offset = 0;
	for (const part of parts) {
		out.set(part, offset);
		offset += part.length;
	}
	return out;
}
function u16be(n) {
	const b = /* @__PURE__ */ new Uint8Array(2);
	new DataView(b.buffer).setUint16(0, n, false);
	return b;
}
function ascii(text) {
	return new TextEncoder().encode(text);
}
function xmpPacket(videoLength) {
	const xml = `<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="0"
    GCamera:MicroVideo="1"
    GCamera:MicroVideoVersion="1"
    GCamera:MicroVideoOffset="${videoLength}">
   <Container:Directory>
    <rdf:Seq>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary"/>
     </rdf:li>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${videoLength}"/>
     </rdf:li>
    </rdf:Seq>
   </Container:Directory>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>`;
	return new TextEncoder().encode(xml);
}
function app1(header, payload) {
	const body = concat([ascii(header), payload]);
	return concat([
		new Uint8Array([255, 225]),
		u16be(body.length + 2),
		body
	]);
}
function insertAfterSoi(jpeg, segment) {
	if (jpeg.length < 2 || jpeg[0] !== 255 || jpeg[1] !== 216) throw new Error("The still image is not a JPEG.");
	return concat([
		jpeg.subarray(0, 2),
		segment,
		jpeg.subarray(2)
	]);
}
function isMp4(data) {
	return data.length > 12 && asciiDecode(data.subarray(4, 8)) === "ftyp";
}
function asciiDecode(data) {
	return String.fromCharCode(...data);
}
/** A JPEG that still opens as a photo, with the motion clip tucked inside. */
function motionJpeg(jpeg, video) {
	if (!isMp4(video)) throw new Error("The motion clip is not a video file.");
	return concat([insertAfterSoi(jpeg, app1("http://ns.adobe.com/xap/1.0/\0", xmpPacket(video.length))), video]);
}
var ALLOWED_HOST = /(^|\.)((tiktokcdn(-us|-eu)?|tiktokv|muscdn|musical\.ly|ibyteimg|byteimg|byteoversea|byteicdn|tikwm|ttwstatic)\.com)$/i;
function isAllowedMediaHost(hostname) {
	return ALLOWED_HOST.test(hostname);
}
function parseMediaUrl(raw) {
	let url;
	try {
		url = new URL(raw);
	} catch {
		return null;
	}
	if (url.protocol !== "https:") return null;
	if (!isAllowedMediaHost(url.hostname)) return null;
	return url;
}
var STILL_MAX = 12582912;
var MOTION_MAX = 20971520;
async function pull(url, max) {
	const upstream = await fetch(url, {
		headers: {
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
			Referer: "https://www.tiktok.com/",
			Accept: "*/*"
		},
		redirect: "follow",
		signal: AbortSignal.timeout(25e3)
	});
	if (!upstream.ok) throw new Error("A Live Photo file could not be fetched.");
	let finalHost = "";
	try {
		finalHost = new URL(upstream.url).hostname;
	} catch {
		finalHost = "";
	}
	if (!parseMediaUrl(`https://${finalHost}/`)) throw new Error("Redirected host is not allowed.");
	if (Number(upstream.headers.get("content-length") || 0) > max) throw new Error("That Live Photo is too large to build.");
	const body = new Uint8Array(await upstream.arrayBuffer());
	if (body.byteLength > max) throw new Error("That Live Photo is too large to build.");
	return body;
}
var Route$2 = createFileRoute("/api/live")({ server: { handlers: { GET: async ({ request }) => {
	const incoming = new URL(request.url);
	const stillUrl = parseMediaUrl(incoming.searchParams.get("still") || "");
	const motionUrl = parseMediaUrl(incoming.searchParams.get("motion") || "");
	if (!stillUrl || !motionUrl) return Response.json({ error: "That Live Photo link is not allowed." }, { status: 400 });
	try {
		const [still, motion] = await Promise.all([pull(stillUrl, STILL_MAX), pull(motionUrl, MOTION_MAX)]);
		const photo = motionJpeg(still, motion);
		const filename = (incoming.searchParams.get("name") || "aiden-knox-live-photo.jpg").replace(/[^a-zA-Z0-9._-]/g, "").replace(/\.mp4$/i, "").slice(0, 80).replace(/\.[a-z0-9]+$/i, "") || "aiden-knox-live-photo";
		const bytes = new ArrayBuffer(photo.byteLength);
		new Uint8Array(bytes).set(photo);
		return new Response(bytes, {
			status: 200,
			headers: {
				"Content-Type": "image/jpeg",
				"Content-Disposition": `attachment; filename="${filename}.jpg"`,
				"Cache-Control": "private, max-age=60",
				"X-Content-Type-Options": "nosniff"
			}
		});
	} catch (err) {
		const message = err instanceof Error ? err.message : "Couldn't build that Live Photo.";
		const status = /not a JPEG|not a video/i.test(message) ? 415 : 502;
		return Response.json({ error: message }, { status });
	}
} } } });
var MAX_BYTES = 83886080;
function safeName(raw, type) {
	const base = ((raw || "aiden-knox").replace(/[^a-zA-Z0-9._-]/g, "").replace(/^\.+/, "").slice(0, 80) || "aiden-knox").replace(/\.[a-z0-9]+$/i, "");
	let ext = "bin";
	if (type.includes("mp4")) ext = "mp4";
	else if (type.includes("mpeg") || type.includes("audio")) ext = "mp3";
	else if (type.includes("webm")) ext = "webm";
	else if (type.includes("webp")) ext = "webp";
	else if (type.includes("png")) ext = "png";
	else if (type.includes("jpeg") || type.includes("jpg")) ext = "jpg";
	else if (type.includes("gif")) ext = "gif";
	return `${base}.${ext}`;
}
function allowedType(type) {
	return type.startsWith("video/") || type.startsWith("audio/") || type.startsWith("image/") || type.startsWith("application/octet-stream");
}
var Route$1 = createFileRoute("/api/media")({ server: { handlers: { GET: async ({ request }) => {
	const incoming = new URL(request.url);
	const src = parseMediaUrl(incoming.searchParams.get("src") || "");
	if (!src) return Response.json({ error: "That file link is not allowed." }, { status: 400 });
	const inline = incoming.searchParams.get("disp") === "inline";
	let upstream;
	try {
		upstream = await fetch(src, {
			headers: {
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
				Referer: "https://www.tiktok.com/",
				Accept: "*/*"
			},
			redirect: "follow",
			signal: AbortSignal.timeout(25e3)
		});
	} catch {
		return Response.json({ error: "The file host did not respond." }, { status: 502 });
	}
	if (!upstream.ok || !upstream.body) return Response.json({ error: "The file could not be fetched." }, { status: 502 });
	if (!parseMediaUrl(`https://${(() => {
		try {
			return new URL(upstream.url).hostname;
		} catch {
			return "";
		}
	})()}/`)) return Response.json({ error: "Redirected host is not allowed." }, { status: 400 });
	const type = (upstream.headers.get("content-type") || "application/octet-stream").split(";")[0].trim().toLowerCase();
	if (!allowedType(type)) return Response.json({ error: "Unexpected file type." }, { status: 415 });
	const length = Number(upstream.headers.get("content-length") || 0);
	if (length > MAX_BYTES) return Response.json({ error: "That file is too large to save here." }, { status: 413 });
	const filename = safeName(incoming.searchParams.get("name"), type);
	const headers = new Headers();
	headers.set("Content-Type", type);
	headers.set("Content-Disposition", `${inline ? "inline" : "attachment"}; filename="${filename}"`);
	headers.set("Cache-Control", "private, max-age=120");
	headers.set("X-Content-Type-Options", "nosniff");
	if (length > 0) headers.set("Content-Length", String(length));
	return new Response(upstream.body, {
		status: 200,
		headers
	});
} } } });
var SAMPLE_URL = "https://www.tiktok.com/@tiktok/video/7106594312292453675";
var TIKTOK_HOST = /^(?:(?:www|m|vm|vt|us|t|vmweb)\.)?tiktok\.com$/i;
function normalizeTikTokUrl(input) {
	const trimmed = input.trim();
	if (!trimmed || trimmed.length > 2e3) return null;
	const found = trimmed.match(/https?:\/\/[^\s<>"']+/i);
	let raw = (found ? found[0] : trimmed).replace(/[),.;]+$/, "");
	if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`;
	let url;
	try {
		url = new URL(raw);
	} catch {
		return null;
	}
	if (url.protocol !== "http:" && url.protocol !== "https:") return null;
	if (!TIKTOK_HOST.test(url.hostname)) return null;
	url.protocol = "https:";
	url.hash = "";
	return url.toString();
}
function parseTikTokTarget(input) {
	const trimmed = input.trim();
	const at = trimmed.match(/^@([A-Za-z0-9._]{2,24})$/);
	if (at) return {
		type: "profile",
		handle: at[1]
	};
	const url = normalizeTikTokUrl(trimmed);
	if (!url) return null;
	const parts = new URL(url).pathname.split("/").filter(Boolean);
	if (parts.length === 1 && parts[0].startsWith("@") && parts[0].length > 1) {
		const handle = parts[0].slice(1);
		if (!/^[A-Za-z0-9._]{2,24}$/.test(handle)) return null;
		return {
			type: "profile",
			handle
		};
	}
	return {
		type: "post",
		url
	};
}
function formatDuration(sec) {
	if (!sec || sec <= 0) return null;
	return `${Math.floor(sec / 60)}:${Math.round(sec % 60).toString().padStart(2, "0")}`;
}
function formatCount(n) {
	if (n == null || n < 0) return null;
	return new Intl.NumberFormat("en", {
		notation: "compact",
		maximumFractionDigits: 1
	}).format(n);
}
function fileSlug(handle, id) {
	const who = handle.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 24);
	const post = id.replace(/[^a-z0-9]/gi, "").slice(0, 12);
	return [
		"aiden-knox",
		who || "tiktok",
		post
	].filter(Boolean).join("-");
}
function mediaHref(src, filename, inline = false) {
	const q = new URLSearchParams({
		src,
		name: filename
	});
	if (inline) q.set("disp", "inline");
	return `/api/media?${q.toString()}`;
}
var LOOKUP = "https://www.tikwm.com/api/";
var PROFILE = "https://www.tikwm.com/api/user/info/";
function asRecord(v) {
	return v !== null && typeof v === "object" ? v : null;
}
function str(v) {
	return typeof v === "string" ? v.trim() : "";
}
function num(v) {
	const n = typeof v === "number" ? v : typeof v === "string" ? Number(v) : NaN;
	return Number.isFinite(n) ? n : null;
}
function httpsMedia(v) {
	const value = str(v);
	if (!value) return null;
	return parseMediaUrl(value)?.toString() ?? null;
}
function looksJpeg(url) {
	return !/\.webp(\?|$)/i.test(url);
}
function jpegFirst(urls) {
	return urls.filter((url) => Boolean(url)).find(looksJpeg) ?? null;
}
function slideFrom(item) {
	if (typeof item === "string") {
		const url = httpsMedia(item);
		return url ? {
			url,
			motion: null
		} : null;
	}
	const rec = asRecord(item);
	if (!rec) return null;
	const url = httpsMedia(rec.url ?? rec.image ?? rec.src ?? rec.display_image);
	if (!url) return null;
	return {
		url,
		motion: httpsMedia(rec.video ?? rec.play ?? rec.motion ?? rec.video_url)
	};
}
function photosFrom(data) {
	if (!Array.isArray(data.images)) return [];
	const out = [];
	for (const item of data.images) {
		const slide = slideFrom(item);
		if (slide) out.push(slide);
	}
	return out;
}
function friendly(msg) {
	const t = msg.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
	if (/limit|too many|frequent|request\/second/i.test(t)) return "Too many lookups at once. Wait a moment and try again.";
	if (/private/i.test(t)) return "That post is private or unavailable.";
	if (/url|pars|not found|invalid|empty/i.test(t)) return "That link didn't resolve. Use a public TikTok video or photo link.";
	return t.slice(0, 180) || "Couldn't download that post.";
}
function mapPayload(data, sourceUrl, avatarUrl, avatarIsHd) {
	const author = asRecord(data.author);
	const music = asRecord(data.music_info);
	const photos = photosFrom(data);
	const videoUrl = httpsMedia(data.play);
	const hdCandidate = httpsMedia(data.hdplay);
	const hdUrl = hdCandidate && hdCandidate !== videoUrl ? hdCandidate : null;
	const motion = hdUrl ?? videoUrl;
	const audioUrl = httpsMedia(data.music) ?? httpsMedia(music?.play);
	const id = str(data.id) || "post";
	const title = str(data.title) || "TikTok post";
	const durationSec = num(data.duration);
	const cover = httpsMedia(data.cover) ?? httpsMedia(data.origin_cover);
	const liveStill = jpegFirst([
		cover,
		httpsMedia(data.origin_cover),
		photos[0]?.url
	]);
	const slideMotions = photos.filter((photo) => photo.motion).length;
	const isLive = Boolean(liveStill && motion && (durationSec != null && durationSec > 0 && durationSec <= 6 && photos.length <= 1 || photos.length === 1 && photos[0]?.motion));
	if (!videoUrl && !hdUrl && photos.length === 0 && !audioUrl && !avatarUrl) throw new Error("No downloadable file was published for that post.");
	let kind = "video";
	if (isLive) kind = "live";
	else if (!videoUrl && !hdUrl && photos.length > 0) kind = "photo";
	return {
		id,
		sourceUrl,
		kind,
		title,
		authorName: str(author?.nickname) || "TikTok",
		authorHandle: str(author?.unique_id),
		cover,
		durationSec,
		plays: num(data.play_count),
		likes: num(data.digg_count),
		videoUrl,
		videoBytes: num(data.size),
		hdUrl,
		hdBytes: num(data.hd_size),
		audioUrl,
		audioTitle: str(music?.title) || null,
		photos,
		avatarUrl: avatarUrl ?? httpsMedia(author?.avatar),
		avatarIsHd,
		liveStill: isLive ? liveStill : slideMotions > 0 ? jpegFirst(photos.map((photo) => photo.url)) : null,
		liveMotion: isLive ? photos[0]?.motion ?? motion : photos.find((photo) => photo.motion)?.motion ?? null
	};
}
async function profileAvatar(handle) {
	const endpoint = new URL(PROFILE);
	endpoint.searchParams.set("unique_id", handle);
	const res = await fetch(endpoint, {
		headers: {
			Accept: "application/json",
			"User-Agent": "Mozilla/5.0 (compatible; AidenKnox/1.0)"
		},
		signal: AbortSignal.timeout(2e4)
	});
	if (!res.ok) return null;
	let json;
	try {
		json = await res.json();
	} catch {
		return null;
	}
	const rec = asRecord(json);
	const user = asRecord(asRecord(rec?.data)?.user);
	if (num(rec?.code) !== 0 || !user) return null;
	const larger = httpsMedia(user.avatarLarger);
	const medium = httpsMedia(user.avatarMedium);
	const thumb = httpsMedia(user.avatarThumb);
	const url = larger ?? medium ?? thumb;
	if (!url) return null;
	return {
		url,
		hd: Boolean(larger || medium)
	};
}
function profileMedia(handle, user, avatarUrl, avatarIsHd) {
	return {
		id: str(user.id) || handle,
		sourceUrl: `https://www.tiktok.com/@${handle}`,
		kind: "profile",
		title: str(user.signature) || `${str(user.nickname) || handle} profile picture`,
		authorName: str(user.nickname) || handle,
		authorHandle: str(user.uniqueId) || handle,
		cover: avatarUrl,
		durationSec: null,
		plays: null,
		likes: null,
		videoUrl: null,
		videoBytes: null,
		hdUrl: null,
		hdBytes: null,
		audioUrl: null,
		audioTitle: null,
		photos: [],
		avatarUrl,
		avatarIsHd,
		liveStill: null,
		liveMotion: null
	};
}
async function lookup(url) {
	let last = "Couldn't reach the downloader. Try again in a moment.";
	for (let attempt = 0; attempt < 2; attempt += 1) {
		const res = await fetch(LOOKUP, {
			method: "POST",
			headers: {
				"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
				Accept: "application/json",
				"User-Agent": "Mozilla/5.0 (compatible; AidenKnox/1.0)"
			},
			body: new URLSearchParams({
				url,
				hd: "1"
			}),
			signal: AbortSignal.timeout(2e4)
		});
		if (!res.ok) {
			last = `Lookup failed (${res.status}). Try again.`;
			await new Promise((r) => setTimeout(r, 1200));
			continue;
		}
		let json;
		try {
			json = await res.json();
		} catch {
			throw new Error("The lookup service returned an unexpected response.");
		}
		const rec = asRecord(json);
		const code = num(rec?.code);
		const data = asRecord(rec?.data);
		if (code === 0 && data) {
			const author = asRecord(data.author);
			const handle = str(author?.unique_id);
			let avatarUrl = httpsMedia(author?.avatar);
			let avatarIsHd = false;
			if (handle) {
				await new Promise((r) => setTimeout(r, 1100));
				try {
					const hd = await profileAvatar(handle);
					if (hd) {
						avatarUrl = hd.url;
						avatarIsHd = hd.hd;
					}
				} catch {}
			}
			return mapPayload(data, url, avatarUrl, avatarIsHd);
		}
		const message = friendly(str(rec?.msg));
		if (/wait a moment/i.test(message) && attempt === 0) {
			await new Promise((r) => setTimeout(r, 1300));
			last = message;
			continue;
		}
		throw new Error(message);
	}
	throw new Error(last);
}
async function lookupProfile(handle) {
	const endpoint = new URL(PROFILE);
	endpoint.searchParams.set("unique_id", handle);
	const res = await fetch(endpoint, {
		headers: {
			Accept: "application/json",
			"User-Agent": "Mozilla/5.0 (compatible; AidenKnox/1.0)"
		},
		signal: AbortSignal.timeout(2e4)
	});
	if (!res.ok) throw new Error("Couldn't reach that profile. Try again.");
	let json;
	try {
		json = await res.json();
	} catch {
		throw new Error("The lookup service returned an unexpected response.");
	}
	const rec = asRecord(json);
	const user = asRecord(asRecord(rec?.data)?.user);
	if (num(rec?.code) !== 0 || !user) throw new Error(friendly(str(rec?.msg)));
	const larger = httpsMedia(user.avatarLarger);
	const medium = httpsMedia(user.avatarMedium);
	const avatarUrl = larger ?? medium ?? httpsMedia(user.avatarThumb);
	if (!avatarUrl) throw new Error("No profile picture was published for that account.");
	return profileMedia(handle, user, avatarUrl, Boolean(larger || medium));
}
var Route = createFileRoute("/api/resolve")({ server: { handlers: { POST: async ({ request }) => {
	let body;
	try {
		body = await request.json();
	} catch {
		return Response.json({ error: "Send a TikTok link." }, { status: 400 });
	}
	const target = parseTikTokTarget(str(asRecord(body)?.url));
	if (!target) return Response.json({ error: "Paste a TikTok video, live photo, or profile link." }, { status: 400 });
	try {
		const media = target.type === "profile" ? await lookupProfile(target.handle) : await lookup(target.url);
		return Response.json({ media });
	} catch (err) {
		const message = err instanceof Error ? err.message : "Couldn't download that post.";
		return Response.json({ error: message }, { status: 422 });
	}
} } } });
var rootRouteChildren = {
	IndexRoute: Route$3.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	ApiLiveRoute: Route$2.update({
		id: "/api/live",
		path: "/api/live",
		getParentRoute: () => Route$4
	}),
	ApiMediaRoute: Route$1.update({
		id: "/api/media",
		path: "/api/media",
		getParentRoute: () => Route$4
	}),
	ApiResolveRoute: Route.update({
		id: "/api/resolve",
		path: "/api/resolve",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true
	});
}
//#endregion
export { formatDuration as a, formatCount as i, SAMPLE_URL as n, mediaHref as o, fileSlug as r, parseTikTokTarget as s, router_exports as t };
