//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BsUvZasH.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/live",
			"/api/media",
			"/api/resolve"
		],
		preloads: ["/assets/index-Bdx_3Lhj.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bdx_3Lhj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DLOIyi_E.js"]
	}
} });
//#endregion
export { tsrStartManifest };
